import eth_abi
import os
import subprocess
import time
import datetime
from ast import literal_eval
import requests
import json
import web3
from dotenv import load_dotenv
from hexbytes import HexBytes
from web3.contract import ContractEvent
from web3.contract import Contract
from web3._utils.events import get_event_data
from web3 import Web3
from web3.auto import w3
import directory as directory
all_dirs = directory.all_dirs
import std_functions as f
def change_glob(x,v):
    globals()[x] = v
def filt():
    i_e()
    filt = w3.eth.filter({"address": pairs,'fromBlock':b,'toBlock':e})
    change_glob('event_logs',w3.eth.get_filter_logs(filt.filter_id))
def kek(x):
    st = '"'+str(x)+'"'
    return w3.keccak(text=str(x)).hex()
def check_sum(x):
    return Web3.toChecksumAddress(str(x))
def catchup():
    while len(event_logs) == 0:
        filt()
        
def get_cont(x,y):
    get_abi(y)
    cont = w3.eth.contract(x,abi = abi)
    change_glob('cont',cont)
    return cont
def get_abi(x):
    x = f.js_it(reader_C(x))
    return x
def reader_C(file):
    with open(file, 'r',encoding='utf-8-sig') as f:
        text = f.read()
        return text
def read_hex(hb):
    h = "".join(["{:02X}".format(b) for b in hb])
    return '0x'+h
def exists(x):
    try:
        x = f.reader(x)
        return x
    except:
        return ''
def get_em(net):
    from web3 import Web3, HTTPProvider
    hhhh = Web3(HTTPProvider(net))
    return hhhh.eth.blockNumber
def i_e():
    change_glob('b',e)
    change_glob('e',int(int(e)+int(2048)))
    f.pen(e,f.create_path(all_dirs['python_vars'],'last_block.txt'))
def get_hex_data(x):
    n = len(x)
    hex = x
    return int(hex, n)
def mains(x):
    from web3 import Web3
    global net,ch_id,main,file,w3,last_api,c_k,hashs_js,expo,dec,abi
    #abi = reader_C(f.create_path(all_dirs['python_vars'],'/abi.json'))
    hashs_js = ''
    last_api = [0,0]
    scan = ['avax','polygon','ethereum','cronos_test','optimism','binance']
    main = {
        'avax':{'net':'https://api.avax-test.network/ext/bc/C/rpc','chain':'43114','main':'AVAX'},
            'polygon':{'net':'https://polygon-rpc.com/','chain':'137','main':'MATIC'},
            'ethereum':{'net':'https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161','chain':'1','main':'ETH'},
            'cronos_test':{'net':'https://cronos-testnet-3.crypto.org:8545/','chain':'338','main':'TCRO'},
            'optimism':{'net':'https://kovan.optimism.io','chain':'69','main':'OPT'},
            'binance':{'net':'https://bsc-dataseed.binance.org/','chain':'56','main':'bsc'}
            }
    expo = ''
    dec = ''
    main = main[x]
    net,ch_id,main,file,w3 = main['net'],main['chain'],main['main'],str(x)+'.txt',Web3(Web3.HTTPProvider(main['net']))
    c_k = 0
    return net,ch_id,main,file,w3

net,ch_id,main,file,w3 = mains('avax')
desired_1 = kek('SetAutomatedMarketMakerPair(address,bool)')
add_hash = '0x01ED1236B20FC9D8E8200F3783d68E2832776d2e','0x606d1cba470f30b7499fd69128c3ae90436c12ff57f81a8986add303c9170cd6'
pairs = check_sum(add_hash[0])
#cont = get_cont(pairs,f.create_path(all_dirs['python_vars'],'/abi.json'))
tx_receipt = w3.eth.get_transaction_receipt(add_hash[1])
for i in range(0,len(tx_receipt.logs)):
    if read_hex(tx_receipt.logs[i].topics[0]).lower() == desired_1:
        data = w3.toHex(tx_receipt.logs[i].topics[1])
        x = Web3.toChecksumAddress('0x' + data[-40:])


            
