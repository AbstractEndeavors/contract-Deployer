import std_functions as f
import main_functions as main_f
import constructor as const_f
import contract_splitter as splitter
import json
def y_n(x):
    if x == 'n' or x == 'N':
        return False
    return True
def clean_list(x,y):
    ls = []
    for i in range(0,len(x)):
        if x[i] not in y:
            ls.append(x[i])
    return ls
def ask_it(x,y):
    cou = 0
    ask = ''
    ls = []
    for i in range(0,len(x)):
        if '.sol' in x[i] and x[i] not in y:
            ls.append(x[i])
            ask = ask + alph[cou] + ') '+str(x[i])+'\n'
            cou = cou + 1
    return ask,ls
def loop_ask(x,ls):
    og = len(ls)
    list = []
    go = 1
    for i in range(0,len(ls)):
        go = 1
        while go == 1:
            ask,x = ask_it(x,ls)
            if og == len(list):
                return list
            print('order \n 0) to exit\n'+ls_it(ls))
            inp = input('which one is first?\n'+ask)
            if str(inp) == '0':
                return list
            num = f.find_it(alph,str(inp))
            if int(num) > len(ls):
                print('looks like that was out of raange,try again')
            else:
                go = 0
        list.append(ls[num])
        ls = clean_list(ls,list)
        print(list)
    return list
def ask_n_find(x,y):
    return f.find_it(inp_it(x+'\n'+ls_it(y)),alph)
def inp_it(x):
    inp = input(x)
    return inp
def ls_it(x):
    ask = ''
    for i in range(0,len(x)):
        ask = ask + alph[i]+') '+x[i]+'\n'
    return ask
def get_only_sol(x,y):
    ls = []
    for i in range(0,len(x)):
        if y in x[i]:
            ls.append(x[i])
    return ls

def get_all_new(x,place):
    na = ["names","adds"]
    ar = ["vars","const_vars","deplo"]
    js = '{}'
    js = json.loads(js)
    var = {"count":"0","names":[],"adds":{},"all":{}}
    var2 = {"count":"0","names":[],"adds":{}}
    for i in range(0,len(x)):
        file = x[i]
        name = file.replace('.sol','')
        ar_var = {"vars":[],"const_vars":[],"deplo":""}
        args,js,var_ls = const_f.new_const_get(file,place,js)
        splitter.split_it(file,place)
        js,var,var2 = main_f.comp_const_args_test(var_ls,name,["const_vars","deplo"],json.loads(str(js).replace("'",'"')),var,var2,x)
        var[na[0]].append(name)
        var[na[1]] = str(str(var[na[1]])[:-1]+',"'+str(name)+'":""}').replace('{,','{')
        var2[na[0]].append(name)
        var2[na[1]] = str(str(var[na[1]])[:-1]+',"'+str(name)+'":""}').replace('{,','{')
        
    var["all"] = js
    var = f.js_it(str(var).replace("'{",'{').replace("}'",'}'))
    var2 = f.js_it(str(var2).replace("'{",'{').replace("}'",'}'))
    return var,var2
def new_dir():
    f.do_the_dir(all_dirs['temp'])
    f.clean_folder(all_dirs['temp'])
    go = 0
    while go == 0:
        import_ask = input('where would you like to pull the files from?')
        curr_folds = f.list_files(all_dirs['deploy_batches'])
        temp_name = input('what would you like to call the batch?')
        temp_name = str(temp_name)
        if temp_name == "":
            temp_name = 'default'
        if temp_name in curr_folds:
            if 'default' in curr_folds:
                i = 0
                while 'default'+str(i) in curr_folds:
                    i = i + 1
                temp_name = 'default'+str(i)
                go = 1
            else:
                print('name is already taken')
        else:
            go = 1
        
    
    destination = f.create_path(all_dirs['deploy_batches'],temp_name)
    cont_dir = '/home/rugz/Desktop/main_contract_program/contracts'#import_ask#= input('where would you like to pull the contracts from?')
    list_conts = get_only_sol(f.list_files(cont_dir),'.sol')
    l = len(list_conts)
    if l != int(0):
        if l == int(1):
            if y_n(input('would you like to pull the '+str(list_conts[0])+' contract?'))!= False:
                split_it.split_it(temp_name,all_dirs['deploy_batches'])
                ls_conts = [list_conts[0]]
        elif (int(l) > int(1)):
            ls_conts = loop_ask('which one would you like to use?',list_conts)
            print(ls_conts)
            f.clean_folder(all_dirs['temp'])
            for i in range(0,len(ls_conts)):
                f.copy_it(f.create_path(cont_dir,ls_conts[i]),f.create_path(all_dirs['temp'],ls_conts[i]))
    
    #if y_n(input('would you like to save this deploy for future use?\n\n'))!= False:
    var,var2 = get_all_new(ls_conts,all_dirs['temp'])
    f.fold_rename(all_dirs['temp'],destination)
    f.create_new_dirs(temp_name,'variables')
    new_samp = f.reader(f.create_path(all_dirs['var_samples'],'alls_sample.txt'))
    new_samp = new_samp.replace('^^^varis^^^',str(var))
    new_samp = new_samp.replace('^^^destination^^^',str(destination))
    f.pen(new_samp,f.create_path(destination,'alls.py'))
    f.pen(new_samp,f.create_path(all_dirs['current'],'varis.txt'))
    f.pen(var,f.create_path(all_dirs['current'],'alls.py'))
    f.pen(var2,f.create_path(all_dirs['current'],'varis.txt'))
    f.do_the_dir(all_dirs['temp'])
    f.clean_folder(all_dirs['temp'])
    return destination
def old_dir():
    list = clean_list(f.list_files(all_dirs['deploy_batches']),['temp'])
    ask = input('which one would you like to use?\n'+str(ls_it(list)))
    num = f.find_it_alph(f.get_alph(),str(ask))
    destination = f.create_path(all_dirs['deploy_batches'],list[num])
    f.copy_it(f.create_path(destination,'varis.txt'),f.create_path(all_dirs['current'],'varis.txt'))
    f.copy_it(f.create_path(destination,'alls.py'),f.create_path(all_dirs['current'],'alls.py'))
    return destination
def current_dir():
    varis_done= f.js_it(f.exists_make(varis,f.create_path(all_dirs['current'],'varis.txt')))
    count_done = int(varis_done["count"])
    if int(count_done) != int(0):
        ask = input("would you like to start with the old varis count at:"+varis["names"][count_done]+"?")
        if ask != 'n' and ask != 'N' and ask != 'no':
            varis = varis_done
            count = count_done
        else:
            pri = ''
            for i in range(0,count_done):
                pri = pri + str(i)+') '+str(varis["names"][i])+'\n'
            ask = input('where did you want to start?\n'+pri)
            if ask != 'n' and ask != 'N' and ask != 'no':
                varis = varis_done
                count = int(ask)
    return all_dirs['current']

global alph,all_dirs
alph = f.get_alph()
all_dirs = f.js_it(f.reader('all_dirs.json'))
