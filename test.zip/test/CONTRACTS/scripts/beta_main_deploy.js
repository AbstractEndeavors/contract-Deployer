require("@nomiclabs/hardhat-etherscan");
const hre = require("hardhat");
async function main() {
  const Greeter = await hre.ethers.getContractFactory("beta_main");
  const greeter = await Greeter.deploy(['0x449061d1eA17892476F0113CF7D12d9399a93681'], [100], ['0xf8748138e84Fd4Be0173581861503Df3B487Cb5d', '0xa7Bc73BD376D1dE8F68FA2D3797aAA85860BDDb3', '0xb6344ec4f1390ded6d9283ba1d69a1135e432034'], [10, 80, 10, 10, 90], ['0xa888c199f30582ebe2fea6bbea9ccd4ed169ba5c', '0x0504de4fb8d84f1b9ee76dd1597b25f29fce9565', '0x03dad4073dd36e607865e6037b993ed179171171']);
  await greeter.deployed();
  console.log("Greeter deployed to:", greeter.address);
}
function link(bytecode, libName, libAddress) {
  let symbol = "__" + libName + "_".repeat(40 - libName.length - 2);
  return bytecode.split(symbol).join(libAddress.toLowerCase().substr(2))
}
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
