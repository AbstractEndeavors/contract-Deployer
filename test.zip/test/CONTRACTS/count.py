import functions as f
import os
home = f.home_it()
files = f.list_files(home[0])
k = 0
for i in range(0,len(files)):
    ii = 0
    if '.sol' in str(files[i]): 
        li = f.read_lines(files[i])
        
        while 'pragma' not in str(li[ii]):
            ii = ii - 1
            print(li[ii].replace('\n',''))
            print(ii)
        input('press enter')
    k = k + ii

print(k)
