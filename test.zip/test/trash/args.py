import std_functions as f
def get_const(readem):
    start = 0
    l = 0
    r = 0
    n = 0
    for i in range(0,len(readem)):
        if readem[0] == '{':
            l = l + 1
            start = 1
        if readem[0] == '}':
            r = r + 1
            if l == r:
                n = n.replace('  ','')
                return n
        if start == 1:
            if n != 0:
                n = n + readem[0]
            else:
                n = ''
        readem = readem[1:]
def make_js(x,y):
    js = '{'
    for i in range(0,len(x)):
        if x[i] not in y:
            js = js+',"'+x[i]+'":""'
        else:
            js = js+',"'+x[i]+'":[]'
    js = js.replace('{,','{')+'}'
    return js
def new_const_get(file,original_path):
    name = file.replace('.sol','')
    flat_path = original_path+'/flattened/'+str(name)+'/main/'
    flat_file_path = f.create_path(flat_path,file)
    readem = f.reader(original_path+'/'+file).replace('\n','^&^')
    readem.replace('constructor','\nconstructor')
    readem = 'constructor'+readem.split('constructor')[-1]
    units = readem.split(')')[0].split('(')[1].replace(' ','*').split(',')
    var_all = []
    var_ls = []
    var_type =[]
    var_ls_type =[]
    for i in range(0,len(units)):
        while units[i][0] in ['*','^','&']:
            units[i] = units[i][1:]
        while units[i][-1] in ['*','^','&']:
            units[i] = units[i][:-1]
        units[i] = units[i].replace('*',' ')
        if '[]' in units[i].split(' ')[0]:
            var_ls.append(units[i].split(' ')[-1])
            var_ls_type.append(units[i].replace(' '+units[i].split(' ')[-1],''))
        
        var_all.append(units[i].split(' ')[-1])
        var_type.append(units[i].replace(' '+units[i].split(' ')[-1],''))
    var_js = f.js_it(make_js(var_all,var_ls))
    get = get_const(readem).split('^&^')
    for k in range(0,len(var_ls)):
        n_og = var_ls[k]
        n = n_og + '['
        for i in range(0,len(get)):
            if n in get[i] and ' = ' in get[i]:
                var_js[n_og].append(var_ls_type[k].replace('[]','') + ' '+get[i].split(' = ')[0].replace(' ',''))
    print(var_js)
        
            
        
new_const_get('beta_main.sol','/home/rugz/Desktop/new_contract_dep/test/variables/deploy_batches/temp')
