import os
import json
from datetime import date
import std_functions as f
def date(all_dirs,depo_hist):
    from datetime import date
    today = str(date.today())   # '2017-12-26'
    depo_hist = create_path(depo_hist['deploy_hist'],today)
    print(depo_hist)

    return depo_hist
def change_glob(x,v):
    globals()[x] = v
def check_str(x,y):
    c = ''
    if str(x) != str(y):
        c = y
    return c
def create_path(x,y):
    if x == '':
        return str(y) + str(check_str(str(y),slash))
    return str(x) + str(check_str(x[-1],slash))+str(y)
def change_places(x,y,z):
     x = str(x)[:-1]+',"'+y+'":"'+z+'"}'
     x = json.loads(x.replace('{,','{').replace("'",'"'))
     return x
def go_parent():
    places = json.loads('{}')
    count = len(os.getcwd()) - len(os.getcwd().replace('/',''))
    print(count)
    for i in range(0,count):
        os.chdir("..")
        path =str(os.getcwd()).split('/')[-1]
        places = change_places(places,path,os.getcwd())
    print(places)
    return places
def pen(paper, place):
    with open(place, 'w') as f:
        f.write(str(paper))
        f.close()
        return
def do_the_dir(x):
    if check_dir(x) == False:
        make_dir(x)
    return x
def do_the_file(x,y,z):
    if check_file(x) == False:
        pen(y,z)
        return y
    return reader(z)
def do_all_dir(x):
    m = ''
    all = ''
    for i in range(0,len(x)):
        n = x[i]
        m = create_path(m,n)
        m = m.replace('//','/')
  
        all = do_the_dir(m)
        print(all)
    return all
def make_dir(x):
    if check_dir(x) == False:
        os.makedirs(x)
def check_dir(x):
    return os.path.isdir(x)
def send_all_jsons():
    n = str(all_dirs).replace(' ','').split(',')
    for i in range(1,len(n)):
        nn = n[i]
        nn = nn.split(':')[1].replace(' ','').replace("'",'').replace(os.getcwd(),'').replace('{','').replace('}','')
        nn = nn.split('/')[1:]
        now = str(create_path(do_all_dir(nn),'all_dirs.json'))
        pen(all_dirs,str(now))
global all_dirs,slash
all_dirs = json.loads('{}')
slash = '/'
home = os.getcwd()
#home
all_dirs = change_places(all_dirs,'home',os.getcwd())
depo_hist = change_places(all_dirs,'deploy_hist',create_path(all_dirs['home'],'deploy_hist'))
#contracts
all_dirs = change_places(all_dirs,'contracts',create_path(all_dirs['home'],'contracts'))
all_dirs = change_places(all_dirs,'scripts',create_path(all_dirs['home'],'scripts'))
all_dirs = change_places(all_dirs,'flattened',create_path(all_dirs['scripts'],'flattened'))
all_dirs = change_places(all_dirs,'solidity-flattener',create_path(all_dirs['flattened'],'solidity-flattener'))
all_dirs = change_places(all_dirs,'save',create_path(all_dirs['flattened'],'save'))
all_dirs = change_places(all_dirs,'main',create_path(all_dirs['save'],'main'))
all_dirs = change_places(all_dirs,'deploy_hist',create_path(all_dirs['home'],'deploy_hist'))
all_dirs = change_places(all_dirs,'variables',create_path(all_dirs['deploy_hist'],'varibles'))
all_dirs = change_places(all_dirs,'current',create_path(all_dirs['deploy_hist'],'current'))
#python
all_dirs = change_places(all_dirs,'python_scripts',create_path(all_dirs['home'],'python_scripts'))
all_dirs = change_places(all_dirs,'python_vars',create_path(all_dirs['python_scripts'],'python_vars'))
all_dirs = change_places(all_dirs,'terminal',create_path(all_dirs['python_vars'],'terminal'))
all_dirs = change_places(all_dirs,'program_core',create_path(all_dirs['python_scripts'],'program_core'))
all_dirs = change_places(all_dirs,'solidity',create_path(all_dirs['program_core'],'solidity'))
all_dirs = change_places(all_dirs,'functions',create_path(all_dirs['python_scripts'],'functions'))
#bash
all_dirs = change_places(all_dirs,'bash',create_path(all_dirs['home'],'bash'))
all_dirs = change_places(all_dirs,'terminal',create_path(all_dirs['bash'],'terminal'))
all_dirs = change_places(all_dirs,'samples',create_path(all_dirs['variables'],'samples'))
#varis
all_dirs = change_places(all_dirs,'variables',create_path(all_dirs['home'],'variables'))
all_dirs = change_places(all_dirs,'current',create_path(all_dirs['variables'],'current'))
all_dirs = change_places(all_dirs,'var_samples',create_path(all_dirs['variables'],'samples'))
all_dirs = change_places(all_dirs,'deploy_batches',create_path(all_dirs['variables'],'deploy_batches'))
all_dirs = change_places(all_dirs,'new',create_path(all_dirs['deploy_batches'],'new'))
all_dirs = change_places(all_dirs,'temp',create_path(all_dirs['deploy_batches'],'temp'))

pen(all_dirs,'all_dirs.json')


