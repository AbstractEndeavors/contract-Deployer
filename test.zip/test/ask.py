import std_functions as f
import ask_functions as ask_f
all_dirs = f.js_it(f.reader('all_dirs.json'))
alpha = f.get_alph()
def start_it():
    f.do_the_dir(all_dirs['deploy_batches'])
    if len(ask_f.clean_list(f.list_files(all_dirs['deploy_batches']),'temp')) != 0:
        go = 0
        while go == 0:
            sets = ['new','old','current']
            ask = input('do you have a new set, old set, or current set?\n'+str(ask_f.ls_it(sets)))
            if str(ask) not in alpha:
                print('please enter a correct input (not in alphabet)')
            elif int(f.find_it_alph(alpha,str(ask))) > len(sets):
                print('please enter a correct input (too high)')
            else:
                set_q = str(sets[f.find_it_alph(alpha,str(ask))])
                go = 1
    else:
        set_q = 'new'
    if set_q == 'new':
        curr_dep = ask_f.new_dir()
    if set_q == 'old':
        curr_dep = ask_f.old_dir()
    if set_q == 'current':
        curr_dep = ask_f.current_dir()
    varis = f.js_it(f.reader(f.create_path(all_dirs['current'],'varis.txt')))
    alls = f.js_it(f.reader(f.create_path(all_dirs['current'],'alls.py')))
    return curr_dep,varis,alls

