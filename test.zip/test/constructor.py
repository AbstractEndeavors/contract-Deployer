import std_functions as f
import json
def get_const(readem):
    start = 0
    l = 0
    r = 0
    n = 0
    for i in range(0,len(readem)):
        if readem[0] == '{':
            l = l + 1
            start = 1
        if readem[0] == '}':
            r = r + 1
            if l == r:
                n = n.replace('  ','')
                return n
        if start == 1:
            if n != 0:
                n = n + readem[0]
            else:
                n = ''
        readem = readem[1:]
def make_js(x,y):
    js = '{'
    for i in range(0,len(x)):
        if x[i] not in y:
            js = js+',"'+x[i]+'":""'
        else:
            js = js+',"'+x[i]+'":[]'
    js = js.replace('{,','{')+'}'
    return js
def get_len(x):
    if len(str(x)) >= int(1):
        return False
    return True
def new_const_get(file,original_path,js):
    js = f.js_it(js)
    var_all = []
    var_ls = []
    var_type =[]
    var_ls_type =[]
    name = file.replace('.sol','')
    xx = str(str(js)[:-1]+',\n"'+str(name)+'":{"vars":[],"const_vars":[],"deplo":""}}').replace('{,\n','{').replace("'",'"')
    js = json.loads(xx)
    first = 'contract '+name
    flat_file_path = f.create_path(original_path,file)
    n = f.line_num(first,flat_file_path)
    readem = f.reader(original_path+'/'+file).replace('\n','^&^')
    n_test = f.line_num('constructor',flat_file_path)
    
    if len(n_test) == 0 or len(n) == 0:
        return None,js,var_ls
    ask = n_test[0]
    if len(n_test) > 1:
        ask = n_test[-1]
    if int(n[0]) > int(ask):
        return None,js,var_ls
    readem.replace('constructor','\nconstructor')
    readem = 'constructor'+readem.split('constructor')[-1]
    units = readem.split(')')[0].split('(')[1].replace(' ','*').split(',')
    for i in range(0,len(units)):
        n = units[i].replace('^&^','')
        while n[0] in ['*','^','&'] and get_len(n) != False:
            n = n[1:]
        while n[-1] in ['*','^','&'] and get_len(n) != False:
            n = n[:-1]
        units[i] = n.replace('*',' ').replace('  ','')
        if '[]' in units[i].split(' ')[0]:
            var_ls.append(units[i].split(' ')[-1])
            var_ls_type.append(units[i].replace(' '+units[i].split(' ')[-1],''))
            js[name]["vars"].append([])
            js[name]["const_vars"].append([])
        else:
            if 'uint' in units[i].split(' ')[0]:
                js[name]["vars"].append('0')
                js[name]["const_vars"].append('0')
            else:
                js[name]["vars"].append(units[i].split(' ')[-1])
                js[name]["const_vars"].append('*')
        var_all.append(units[i].split(' ')[-1])
        var_type.append(units[i].replace(' '+units[i].split(' ')[-1],''))
    var_js = f.js_it(make_js(var_all,var_ls))
    get = get_const(readem).split('^&^')
    for k in range(0,len(var_ls)):
        n_og = var_ls[k]
        n = n_og + '['
        for i in range(0,len(get)):
            if n in get[i] and ' = ' in get[i]:
                print(get[i])
            if n in get[i] and ' = ' in get[i]:
                types = var_ls_type[k].replace('[]','')
                new_var = types + ' '+get[i].split(' = ')[0].replace(' ','')
                var_js[n_og].append(new_var)
                if 'uint' in types:
                    js[name]["vars"][k].append('0')
                    js[name]["const_vars"][k].append('0')
                else:
                    js[name]["vars"][k].append(new_var)
                    js[name]["const_vars"][k].append('*')
                print(new_var)
    print(js)
    
    return var_js,js,units
            
        
