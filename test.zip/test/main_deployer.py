import os
import subprocess
import time
import datetime
import requests
import json
import subprocess, signal
import directory as di
import std_functions as f
import main_functions as main_f
import constructor as const_f
import contract_splitter as splitter
import enc as enc
import p_k as key
import clipboard
global all_dirs,pragmas,dep_str,alls,ad,args,cou,save_it,varis,scanners,net,ch_id,main_tok,file,w3,network,name,verify_strs,dec,new_dep,alph
all_dirs = f.js_it(f.reader('all_dirs.json'))
import ask as ask_it
slash,cou,args = di.slash,0,''
str_names = ["api","contract_address","contract","name","version","args","license"]
dec = 18
alpha = f.get_alph()
scanners,net,ch_id,main_tok,file,w3,network = f.mains()
strs = ["str_names","verify_strs","pragmas","dep_str","adds","alls"]
account_1 = w3.eth.account.privateKeyToAccount(key.p)
curr_dep,varis,alls = ask_it.start_it()
print(curr_dep,varis,alls)
