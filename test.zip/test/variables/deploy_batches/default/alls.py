from web3 import Web3
import json
import functions as f
import p_k as key
destination = /home/rugz/Desktop/new_contract_dep/test/variables/deploy_batches/default
def get_itter(x):
    return str('{libraries:{IterableMapping:"'+str(x)+'"}},')
all_dirs = f.js_it(f.reader('all_dirs.json'))
scanners,net,ch_id,main_tok,file,w3,network = f.mains()
account_1 = w3.eth.account.privateKeyToAccount(key.p)
varis = {'count': '0', 'names': ['tier_3', 'tier_1', 'IterableMapping', 'overseer', 'beta_main', 'NodeManager', 'MainStaking', 'tier_2', 'NftStakingContract'], 'adds': {'tier_3': '', 'tier_1': '', 'IterableMapping': '', 'overseer': '', 'beta_main': '', 'NodeManager': '', 'MainStaking': '', 'tier_2': '', 'NftStakingContract': ''}, 'all': {'tier_3': {'vars': ['_name', '_symbol'], 'const_vars': ['tier_3', '_symbol'], 'deplo': ''}, 'tier_1': {'vars': ['_name', '_symbol'], 'const_vars': ['tier_1', '_symbol'], 'deplo': ''}, 'IterableMapping': {'vars': [], 'const_vars': [], 'deplo': ''}, 'overseer': {'vars': [], 'const_vars': [], 'deplo': ''}, 'beta_main': {'vars': [[], [], ['address memory teamPool', 'address memory rewardsPool', 'address memory nodeManager'], ['0', '0', '0', '0', '0'], ['address memory tier_1', 'address memory tier_2', 'address memory tier_3'], '0'], 'const_vars': ['payees', 'shares', 'addresses', 'fees', 'nfts', 'swapAmount'], 'deplo': ''}, 'NodeManager': {'vars': ['0', '0'], 'const_vars': ['_rewardPerNode', '_minPrice'], 'deplo': ''}, 'MainStaking': {'vars': ['_Proto', '0'], 'const_vars': ['_Proto', '_poolStartTime'], 'deplo': ''}, 'tier_2': {'vars': ['_name', '_symbol'], 'const_vars': ['tier_2', '_symbol'], 'deplo': ''}, 'NftStakingContract': {'vars': [], 'const_vars': [], 'deplo': ''}}}
varis = f.js_it(f.exists_make(varis,f.create_path(all_dirs['variables'],'varis.txt')))
adds = f.js_it(f.exists_make(varis,f.create_path(all_dirs['variables'],'varis.txt')))["adds"]


