import os
import json
def reader(file):
    with open(file, 'r') as f:
        text = f.read()
        return text
all_d = json.loads(reader('all_dirs.json').replace("'",'"'))
os.chdir(all_d['home'])
import sys
sys.path.append(all_d['home'])
import directory as directory
import std_functions as f
import time

def go_check(w,x,y,z):
    if in_check(w,x) == True:
        return True
    return False
def in_check(x,y):
    l = len(str(x))
    if type(y) is not list:
        y = [y]
    for i in range(0,len(y)):
        if str(x) in str(y[i])[:l-1]:
            
            if l == len(y[i]):
                
                return False
            return True
    return False

def go_str_check(w,x):
    if str_check(w,x) == True:
        return True
    return False
def str_check(x,y):
    if type(y) is not list:
        y = [y]
    if x in y:
        return True
    return False
def check_str(x,y):
    c = ''
    if str(x) != str(y):
        c = y
    return c
def create_path(x,y):
    return str(x) + str(check_str(x[-1],slash))+str(y)
def flatten_it(x):
    pa = f.create_path(f.do_the_dir(all_dirs['terminal']),str(name_all))+'_build_up.txt'
    f.pen('cd '+all_dirs['solidity-flattener'].split('Desktop')[1]+'; npm start "'+str(x)+'";',pa)
    bash_it(pa)
    return pa
def bash_it(x):
    global name_all,cou
    save = f.exists_make('',(create_path(all_dirs['terminal'],'split_build_up.txt'))) + str(x) + ' >> '+create_path(all_dirs['terminal'],str(name_all)+'.txt')+';'
    f.pen(save,create_path(all_dirs['terminal'],'split_build_up.txt'))
def bash_it_good(pa):
    global name_all,cou
    x = f.reader(pa)
    sh_str = f.reader(create_path(all_dirs['samples'],'samplesh.txt'))
    f.pen(sh_str.replace('^^killme^^',x+'echo im done >> '+str(pa)+'; exit;'),create_path(all_dirs['bash'],'script.sh'))
    gnome = "gnome-terminal -x ./bash/script.sh"
    p = os.popen(gnome ).read()
    while 'im done' not in f.read_lines(pa)[-1]:
        time.sleep(2)
        print('waiting for exit')
    
    f.pen(f.reader(pa).replace('im done','ended'),pa)
    speak = f.read_lines(pa)
    if len(speak) < int(10):
        x = speak
    else:
        x = speak[-10:-1]
    for i in range(0,len(x)):
        if str(x[i]) != '\n':
            print(x[i].replace('\n',''))
def change_places(x,y,z):
     x = str(x)[:-1]+',"'+y+'":"'+z+'"}'
     x = json.loads(x.replace('{,','{').replace("'",'"'))
     return x
def go_parent():
    places = json.loads('{}')
    count = len(os.getcwd()) - len(os.getcwd().replace('/',''))
    for i in range(0,count):
        os.chdir("..")
        path =str(os.getcwd()).split('/')[-1]
        places = change_places(places,path,os.getcwd())
    return places
def find_it(x,y):
    for i in range(0,len(x)):
        if y == x[i]:
            return i
    return False
def find_be(x,k):
    for i in range(0,len(x)):
        if k < x[i]:
            return x[i-1]
def find_em(x,y):
    
    m = []
    cou = 0
    for i, line in enumerate(x, 1):
        if y in line:
            cou = 1
            
            m.append(i-1)
            
    if cou == 0:
        return 0
    return m
def get_range_funs(w,y,z,i,u):
    x = y
    new = []
    if i < len(w)-1:
        x = find_be(u,w[i+1])+1
    more = return_range(y,x,z)
    for i in range(0,len(more[y:x])):
        new.append(more[y:x])
    return more[y:x]
def get_range(w,y,z,i,u):
    x = y
    if i == len(w)-1:
        #print(u[-1])
        more = return_range(y,u[-1]+1,z)
    elif i < len(w):
         x = find_be(u,w[i+1])
        
         more = return_range(y,x+1,z)
    
    return more,x

def return_range(x,y,z):
    if x == y:
        return z[x:]
    else:
        return z[x:y]
def str_in_it(x,y):
    if type(x) is not list:
        x = [x]
    w = []
    for i in range(0,len(x)):
        if x[i] in str(y):
            w.append(x[i])
        else:
            x.append(False)
    return w
def eat_from_to(w,z):
    ne = ''
    
    ne = z
    z_1 = ''
    z_2 = ''
    z_3 = ''
    for i in range(0,len(w)):
        x,y = w[i]
        res = str_in_it([x,y],z)
        while len(str_in_it([x,y],z)) != 0:
            for i in range(0,len(res)):
                if res[i] != False:
                    if i == 0:
                        ne = z
                        while res[i] not in ne and len(ne) != 0:
                            ne = ne[1:]
                        z_1  = ne[:len(ne)-len(res[i])+1]
                    if i == 1:
                        ne = z.replace(z_1,'')
                        while res[i] not in ne and len(ne) != 0 :
                            ne = ne[1:]
                        z_2  = ne[len(ne):]
            z = z_1 + z_2
        
    return z
def find_range(found,saves,hea_tag,iii,n_all,li,last):

    beg_end = [last[1]]
    for k in range(0,len(li)):

        num = li[k]

        if num > n_all:
            beg_end.append(li[k-1])
            return beg_end
    #elif found - 1 == len(saves):
    #    beg_end = []
    #    for k in range(0,len(li)):
    #       num = li[k]
    #        if num > find_it(hea_tag[saves[iii]],n_all):
    #            beg_end.append(li[k-1])
    #            beg_end.append(all[-1])
    #            return beg_end
    #else:
    #    for k in range(0,len(li)):
    #        num = li[k]
    #        if num > find_it(hea_tag[saves[iii+1]],n_all):
    #            beg_end.append(li[k])
    #            return beg_end
def split_it(file,origin):
    varis = ['function','contract','library','constructor','pragma solidity','import','abstract contract']
    heads= ['contract','library','import','pragma solidity','abstract contract']
    subs = ['function','constructor','modify']
    saves = ['interface','contract','abstract contract','library']
    head_sub = ['contract','library','import','pragma solidity','function','constructor','abstract contract','interface']
    hea = ['contract','library','pragma solidity','import','interface','abstract contract']    
    beg_end = [0,0]
    hea_tag = {'contract':[],'library':[],'pragma solidity':[],'import':[],'interface':[],'abstract contract':[],'constructor':[],'function':[],'modify':[]}
    sub_tag = {'constructor':[],'function':[],'modify':[]}
    name = file.split('.')[0]
    main_fold = str(origin)+'/flattened/'+str(name)+'/main/'
    f.do_the_dir(main_fold)
    ori = f.create_path(origin,file)
    path = ori
    mai = '// SPDX-License-Identifier: (Unlicense)\n'+f.reader(ori).replace('// SPDX-License-Identifier: (Unlicense)','').replace('// SPDX-License-Identifier: MIT','').replace('// SPDX-License-Identifier: (unlicensed)','').replace('// SPDX-License-Identifier: (Unlicensed)','').replace('// SPDX-License-Identifier:  (Unlicensed)','').replace(' // SPDX-License-Identifier: GPL-3.0','').replace('// SPDX-License-Identifier: UNLICENSED\n','').replace('Vapor Nodes','')
    f.pen(mai,ori)
    lones = f.read_lines(ori)
    cou_n = -1
    ner_ner = ''
    ner = []
    for qq in range(0,len(lones)):
        if lones[qq] != '\n':
            if cou_n != -1:
                cou_n = -2
            ner.append(lones[qq])
            ner_ner = ner_ner + str(lones[qq])
        if lones[qq] == '\n' and cou_n != -2:
            cou_n = cou_n + 1
    f.pen(ner_ner,ori)
    f.copy_it(ori,f.create_path(main_fold,file))

    lines = f.read_lines(ori)
    li = find_em(f.read_lines(ori),'}')
    new_line = []
    for ii in range(0,len(head_sub)):
        ne = f.line_num(head_sub[ii],path)
        name = path.split('/')[-1].split('.')[0]
        name_all = name
        for iii in range(0,len(ne)):
            new_line.append(ne[iii])
    f.pen('',create_path(all_dirs['terminal'],str(name_all))+'_build_up.txt')
    all_dirs['save'] = f.create_path(all_dirs['flattened'],name)
    all_dirs['main'] = f.create_path(all_dirs['save'],'main')
    f.do_the_dir(all_dirs['save'])
    f.do_the_dir(all_dirs['main'])
    new_path = create_path(create_path(all_dirs['save'],'main'),str(name)+'.sol')
    f.pen(f.reader(path),new_path)
    pa = flatten_it(new_path)
    new_line.sort()
    all = []   
    newer_line = []
    
    for ii in range(0,len(new_line)):
        new = lines[new_line[ii]]
        
        hi = False
        nm = new
        nnn = ''
        while hi == False and len(nm) != 0:
            nnn = nnn + nm[0]
            hi = (nnn in head_sub)
            nm = nm[1:]
            if nnn in head_sub:
                
                hi = (len(nm) != 0)
                nnnn = ''
                nm = nm[1:]
                while str_check(nm[0],['(',' ',';','\t']) == False and len(nm) != 1:
                    nnnn = nnnn + nm[0]
      
                    hi = (len(nm) != 0)
  
                    nm = nm[1:]
                hea_tag[nnn].append(nnnn)
                hea_tag[nnn].append(new_line[ii])
                all.append(new_line[ii])

    prag_len = len(hea_tag['pragma solidity'])
    nprag = 1
    prag_take = hea_tag['pragma solidity'][nprag]
    
    pragma = lines[prag_take]
    pragma = str(pragma).replace(' <','<')
    if '<' in pragma:
        pragma = str(pragma).replace(' <','<')
        prag_path = f.do_the_dir([all_dirs['variables'],'pragma','ranged'])
    else:
        prag_path = f.do_the_dir([all_dirs['variables'],'pragma',pragma.split(' ')[-1].split(';')[0].split('.')[1]])
    og_prag_path = prag_path
    licens = lines[0]
    prev_last = 0
    momo = 0,0
    
    if 'SPDX-License-Identifier' not in str(licens): 
        licens = '// SPDX-License-Identifier: (Unlicense)\n'
    for ii in range(0,len(all)):
        n_all = all[ii]
        for iii in range(0,len(saves)):
            n_save = saves[iii]
            n_head = hea_tag[n_save]
            if n_all in n_head:
                found = find_it(n_head,n_all)
                if found != False:
                    title = n_head[found - 1]
                    doc = title+'.sol'
                    folder = n_save
                    more,prev_last = get_range(all,prev_last,lines,ii,li)
                    if prag_len-2 > nprag:
                        if hea_tag['pragma solidity'][nprag] < int(n_all):
                            nprag = nprag + 2
                            prag_take = hea_tag['pragma solidity'][nprag]
                            pragma = lines[prag_take]
                            pragma = str(pragma).replace(' <','<')
                            if '<' in pragma:
                                pragma = str(pragma).replace(' <','<')
                                prag_path = f.do_the_dir([all_dirs['variables'],'pragma','ranged'])
                            else:
                                prag_path = f.create_path(f.create_path(all_dirs['variables'],'pragma'),str(pragma.split('.')[1]))
                            f.do_the_dir(prag_path)
                            prag_path = f.create_path(prag_path,hea_tag['pragma solidity'][nprag-1])
                            f.do_the_dir(prag_path)
                            for u in range(0,len(head_sub)):
                                f.do_the_dir(f.create_path(prag_path,head_sub[u]))
                                f.exists_make("{'lines': [], 'funs': [], 'last': '0'}",f.create_path(prag_path,'function.py'))
                                new = str(licens)
                    if 'pragma solidity' not in str(more):
                        new = new + '\n'+pragma+'\n'
                    for iiii in range(1,len(more)):
                        new = new + more[iiii]
                        
                    new_path = f.create_path(all_dirs['save'],doc)
                    f.pen(new,new_path)

                    try:
                        if '<' in pragma:
                            pragma = str(pragma).replace(' <','<')
                            f.pen(new,f.create_path(f.do_the_dir([prag_path,'ranged',n_save]),doc))
                        else:
                            if pragma.split(' ')[-1].split(';')[0] not in prag_path:
                                f.pen(new,f.create_path(f.do_the_dir([prag_path,pragma.split(' ')[-1].split(';')[0],n_save]),doc))
                            else:
                                f.pen(new,f.create_path(f.do_the_dir([prag_path,n_save]),doc))
                    except:
                        prag_path = f.do_the_dir([og_prag_path,pragma.split(' ')[-1].split(';')[0],n_save])
                        
                        f.pen(new,doc)
                    mon_read = f.read_lines(new_path)
                    mon = ''
                    for k in range(0,len(mon_read)):
                    #    if '//' not in str(mon_read[k]):
                        mon = mon + mon_read[k]
                    ne = [0]
                    he = ''
                    new_mon  = ''
                    for k in range(0,len(mon)):
                        he = he +  mon[k]
                        if '/*' in he:
                            ne.append(k-2)
                            new_mon = new_mon + mon[ne[0]:ne[1]]
                            m = ''
                            while '/*' in he and k < len(mon):
                                m = m + mon[k]
                                if '*/' in m:
                                    ne=[k+2]
                                    he = mon[k+1]
                                k = k + 1
                    ne = [0]
                    he = ''
                    
                    mon = new_mon
                    new_mon  = ''
                    for k in range(0,len(mon)):
                        he = he +  mon[k]
                        if '//' in he:
                            if k-2 < 0:
                                ne.append(0)
                            else:
                                ne.append(k-2)
                            new_mon = new_mon + mon[ne[0]:ne[1]]
                            m = ''
                            while '//' in he and k < len(mon):
                                m = m + mon[k]
                                if '\n' in m:
                                    ne=[k+1]
                                    he = mon[k+1]
                                k = k + 1
                    he = new_mon.replace('\n','').replace('\t','').replace('  ',' ').replace('  ','').replace('        ','').replace('    ','').replace('function','\nfunction').replace('"','^*^')
                    try:
                        if '<' in pragma:
                            pragma = str(pragma).replace(' <','<')
                            path = f.create_path(prag_path,'function.py')
                        elif pragma.split(' ')[-1].split(';')[0] not in prag_path:
                            path = f.create_path(f.do_the_dir([prag_path,pragma.split(' ')[-1].split(';')[0]]),'function.py')
                        else:
                            path = f.create_path(prag_path,'function.py')
                        
                    except:
                        prag_path = f.do_the_dir([og_prag_path,pragma.split(' ')[-1].split(';')[0]])
                        path = f.create_path(prag_path,'function.py')
                    
                    he = he.split('\n')
                    fff = json.loads(str(f.exists_make('{"lines": [],"funs":[],"last":0}',path)).replace("'",'"').replace('{,','{'))
                    f_n_ls = []
                    f_ls = []
                    cou = int(fff["last"])
                    he_old = fff["funs"]
                    he_new = ''
                    for k in range(0,len(he)):
                        if he[k][:len('function')] == 'function':
                            spl = he[k].split('function ')
                            if len(spl) > 1:
                                n_spl = spl[1].split('(')[0]
                                if n_spl not in fff["lines"]:
                                    f_n_ls.append(file)
                                    cou = cou +1
                                    fff["lines"].append(n_spl)
                                    fff["funs"].append(str(he[k]))
                                    fff["last"] = int(cou)
                    #print(hea_tag)
                    f.pen(fff,path)
global name_all,all_dirs
home,slash = f.home_it()
all_dirs = all_d
name_all = ''
