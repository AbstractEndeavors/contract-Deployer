from dotenv import load_dotenv
import os

load_dotenv('.env')
p = os.environ.get("privateKey")

