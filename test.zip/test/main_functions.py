import std_functions as f
import ask_functions as ask_f
def dec_ast(x,dec):
    og_dec = dec
    if '*' in str(x):
        x = x.split('*')[0]
        if '.' in str(x):
            bef = x.split('.')[0]
            y = x.split('.')[1]
            while y[-1] == '0':
                y = y[:-1]
            de = len(y)
            dec = int(dec) - int(de)
            y = str(bef) + str(y)
            while y[0] == '0':
                y = y[1:]
            x = y
        x =  int(float(int(x))*float(str('1e'+str(int(dec)))))
        dec = og_dec
    return int(x)
def const_it(x):
    print(x)
    if is_int(x[1]) != True:
        x[1] = x[1].replace("'",'"')
    return read_hex(encode_abi([x[0].replace("'",'"')],[x[1]]))
def read_hex(hb):
    h = "".join(["{:02X}".format(b) for b in hb])
    return h
def get_const_args(name):
    path = '/flattened/'+str(name)+'/'+str(name)+'.sol'
    ne_c = f.line_num('constructor',path)
    const = f.read_lines(path)
    ne_b = f.line_num('{',path)
    while ne_b[0] < ne_c[0]:
        ne_b = ne_b[1:]
    return const[ne_c[0]:ne_b[0]]
def filter_const_args(ran):
    ra = []
    for i in range(0,len(ran)):
        if str(ran[i]) not in ['\n','\t','',' ','constructor(','constructor(\n']:
            if 'constructor(' not in ran[i]:
                ran[i] = ran[i].replace('\n','').replace(',','').replace('constructor(','')
                if ran[i] not in [' ','\t','\n','']:
                    print(ran[i])
                    while ran[i][0] in [' ','\t','\n']:
                        ran[i] = ran[i][1:]
                    ra.append(ran[i])
    return ra
def ask_a(x):
    if str(x).lower() == 'n' or str(x).lower() == 'no':
        return False
    return True
def beg_args(name,alls):
    print(len(alls[name]["vars"]))
    if len(alls[name]["vars"]) == 0:
        return ''
    ran = get_const_args(name)
    ra = filter_const_args(ran)
    return comp_const_args(ra,name,["const_vars","deplo"],alls)
def comp_const_args_test(ra,name,y,alls,var,var2,ls):
    alls = f.js_it(alls)
    vna = ["names","adds"]
    print(name)
    all = []
    ar_whole = ''
    if len(alls[name]["vars"]) == 0:
        return alls,var,var2
    k = 0
    n = alls[name][y[k]]
    v = alls[name]["vars"]
    if k == 0:
        all_new = []
    for i in range(0,len(ra)):
        v_n = v[i]
        nam = 0
        end = ''
        ar_small = ''
        ar_1 = ra[i]
        ar_1 = ar_1.replace('_',' ').split(' ')[0].replace('[]','')
        if 'uint' in str(n[i]):
            end = ''
        if 'address' in str(n[i]):
            end = ' (did you want this to be an address in the list?(enter * after if so)'
        if 'name' in str(ra[i]):
            nam = 1
            end = ' (did you want use '+str(name)+'?(if so press enter)'
        if type(ra[i]) is list:
            nn = n[i]
            new = []
            for ii in range(0,len(nn)):
                new_show = ''
                ar_hold = [ar_1]
                
                ask = input('is '+str(ra[i]) +' '+str(ii)+'for contract '+str(name)+' supposed to be '+str(nn[ii])+str(new_show)+'?'+end)
                if str(ask) == "*":
                    new_ask = input('which would you like to choose?\n'+str(ask_f.ls_it(ls)))
                    num = f.find_it_alph(f.get_alph(new_ask),)
                    set_q = str(sets[num])
                    ask = 'str(varis["adds"]["'+str(new_ask)+'"])'
                    alls[name]['const_vars'][i][ii].append(str(ask))
                    var[vna[0]].append(ask)
                    var[vna[1]] = str(str(var[vna[1]])[:-1]+',"'+str(ask)+'":""}').replace('{,','{')
                    var2[vna[0]].append(name)
                    var2[vna[1]] = str(str(var[vna[1]])[:-1]+',"'+str(ask)+'":""}').replace('{,','{')
                elif 'uint' in str(n[i][ii]):
                    if str(ask) == "":
                        alls[name]['const_vars'][i][ii].append(int(0))
                    else:
                        alls[name]['const_vars'][i][ii].append(str(ask))
                else:
                    if str(ask) == "":
                        if nam == 1:
                            alls[name]['const_vars'][i][ii].append(str(name))
                        else:
                            alls[name]['const_vars'][i][ii].append(str(ra[i].split(' ')[-1]))
                    else:
                        alls[name]['const_vars'][i][ii].append(str(ask))

                
                
        else:
            ar_hold = [ar_1]
            new_show = ''
            ask = input('is '+str(ra[i]) +'for contract '+str(name)+' supposed to be '+str(n[i])+str(new_show)+'?'+end)
            
            if str(ask) == '*':
                new_ask = input('which would you like to choose?\n'+str(ask_f.ls_it(ls)))
                num = f.find_it_alph(f.get_alph(new_ask),)
                set_q = str(sets[num])
                ask = 'str(varis["adds"]["'+str(new_ask)+'"])'
                alls[name]['const_vars'][i] = str(ask)
                var[vna[0]].append(ask)
                var[vna[1]] = str(str(var[vna[1]])[:-1]+',"'+str(ask)+'":""}').replace('{,','{')
                var2[vna[0]].append(name)
                var2[vna[1]] = str(str(var[vna[1]])[:-1]+',"'+str(ask)+'":""}').replace('{,','{')     
            elif 'uint' in str(n[i]):
                if str(ask) == "":
                    alls[name]['const_vars'][i] = '0'
                else:
                    alls[name]['const_vars'][i] = int(ask)
                
            else:    
                if str(ask) ==  "":
                    if nam == 1:
                        alls[name]['const_vars'][i]= str(name)
                    else:
                        alls[name]['const_vars'][i]= str(ra[i].split(' ')[-1])
                else:
                    alls[name]['const_vars'][i]= str(ask)
    return alls,var,var2
def comp_const_args(ra,name,y,alls):
    print(ra,name,y,alls)
    all = []
    ar_whole = ''
    if len(alls[name]["vars"]) == 0:
        return ''
    k = 0
    n = alls[name][y[k]]
    v = alls[name]["vars"]
    if k == 0:
        all_new = []
    for i in range(0,len(ra)):
        v_n = v[i]
        end = ''
        ar_small = ''
        ar_1 = ra[i]
        ar_1 = ar_1.replace('_',' ').split(' ')[0].replace('[]','')
        if 'uint' in str(n[i]):
            
            end = ' (input will be multiplied by 10^'+str(int(dec))+' if * is added to the end of the input): '
        if type(ra[i]) is list:
            nn = n[i]
            new = []
            for ii in range(0,len(nn)):
                new_show = ''
                ar_hold = [ar_1]
                if str(v_n) != '0':
                    new_show = ' ('+v_n[ii]+')'
                ask = input('is '+str(ra[i]) +' '+str(ii)+'for contract '+str(name)+' supposed to be '+str(nn[ii])+str(new_show)+'?'+end)
                new_i = nn[ii]
                if ask_a(ask) == False:
                    ch = False
                    while ch == False:
                        change = input('please input what youd like to change it to:'+end+'\n')
                        if str(end) != '':
                            change = dec_ast(change,dec)
                        v_ch = input('are you sure you want to change '+str(ra[i]) +' '+str(ii) +str(new_show)+' to '+str(change)+'?')
                        if ask_a(v_ch) != False:
                            new_i = change
                            if v_n != 0:
                                varis["adds"][v_n[ii]] = str(change)
                            ch = True
                new.append(new_i)
                new_i = str(new_i)
                if end != '':
                    new_i = int(new_i)
                ar_hold.append(new_i)
                ar_small = ar_small + const_it(ar_hold)    
                all.append(ar_hold)
        else:
            ar_hold = [ar_1]
            new_show = ''
            if str(v_n) != '0':
                new_show = ' ('+v_n+')'
            ask = input('is '+str(ra[i]) +' '+str(i)+'for contract '+str(name)+' supposed to be '+str(n[i])+str(new_show)+'?'+end)
            new = n[i]
            if ask_a(ask) == False:
                    ch = False
                    while ch == False:
                        change = input(ask)
                        if str(end) != '':
                            change = dec_ast(change,dec)
                        v_ch = input('are you sure you want to change '+str(ra[i]) +str(new_show)+' to '+str(change)+'?')
                        if ask_a(v_ch) != False:
                            new = change
                            if v_n != 0:
                                varis["adds"][v_n] = str(change)
                            ch = True
           
            new = str(new)
            if end != '':
                new = int(new)
            ar_hold.append(new)
            ar_small = ar_small + str(const_it(ar_hold)).lower()
            all.append(ar_hold)
        ar_whole = ar_whole + f.get_c(len(ar_whole)).replace(',','" "').replace("\n",'')+ar_small
        all_new.append(new)
    print(all)
    alls[name][y[k]] = all_new
    print(alls[name],ar_whole)

    return ar_whole
#comp_const_args_test(['string memory _name', 'string memory _symbol'],'tier_3',['const_vars', 'deplo'],{'tier_3': {'vars': ['*', '*'], 'const_vars': ['*','*'], 'deplo': ''}})
